# Setup Shizuku di dalam LitedirtVM

## build.gradle.kts (modul app)

```kotlin
dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
```

## AndroidManifest.xml

```xml
<queries>
    <package android:name="moe.shizuku.privileged.api" />
</queries>

<application>
    <provider
        android:name="rikka.shizuku.ShizukuProvider"
        android:authorities="${applicationId}.shizuku"
        android:enabled="true"
        android:exported="true"
        android:multiprocess="false"
        android:permission="android.permission.INTERACT_ACROSS_USERS_FULL" />
</application>
```

## Pemakaian

- Navigasikan ke `ShizukuGuideScreen(onBack = ...)` dari layar pengaturan/root.
- Pasang `ShizukuRestartBanner(state, onOpenGuide = ...)` di layar utama dengan
  `val state by rememberShizukuState()`.
- Wireless debugging hanya ada di Android 11+ pada ponsel host.
- Jika package name proyek bukan `com.litedirt.vm`, ganti di semua file.
