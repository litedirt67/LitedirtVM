package com.litedirt.vm.shizuku

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import rikka.shizuku.Shizuku

const val SHIZUKU_PKG = "moe.shizuku.privileged.api"
const val SHIZUKU_RELEASES_URL = "https://github.com/RikkaApps/Shizuku/releases"

enum class ShizukuState { NOT_INSTALLED, NOT_RUNNING, RUNNING }

fun Context.shizukuState(): ShizukuState {
    val installed = try {
        packageManager.getPackageInfo(SHIZUKU_PKG, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }
    return when {
        !installed -> ShizukuState.NOT_INSTALLED
        runCatching { Shizuku.pingBinder() }.getOrDefault(false) -> ShizukuState.RUNNING
        else -> ShizukuState.NOT_RUNNING
    }
}

fun Context.openDeveloperOptions() {
    val flags = Intent.FLAG_ACTIVITY_NEW_TASK
    try {
        startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(flags))
    } catch (e: ActivityNotFoundException) {
        runCatching {
            startActivity(Intent(Settings.ACTION_DEVICE_INFO_SETTINGS).addFlags(flags))
        }
    }
}

/** Buka aplikasi Shizuku; jika belum terpasang, buka halaman rilisnya. */
fun Context.openShizukuOrInstall() {
    val flags = Intent.FLAG_ACTIVITY_NEW_TASK
    val launch = packageManager.getLaunchIntentForPackage(SHIZUKU_PKG)
    runCatching {
        if (launch != null) {
            startActivity(launch.addFlags(flags))
        } else {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(SHIZUKU_RELEASES_URL)).addFlags(flags)
            )
        }
    }
}

/** State Shizuku yang diperbarui otomatis (listener binder + ON_RESUME). */
@Composable
fun rememberShizukuState(): State<ShizukuState> {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val state = remember { mutableStateOf(context.shizukuState()) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) state.value = context.shizukuState()
        }
        val received = Shizuku.OnBinderReceivedListener { state.value = context.shizukuState() }
        val dead = Shizuku.OnBinderDeadListener { state.value = context.shizukuState() }

        lifecycleOwner.lifecycle.addObserver(observer)
        Shizuku.addBinderReceivedListenerSticky(received)
        Shizuku.addBinderDeadListener(dead)

        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            Shizuku.removeBinderReceivedListener(received)
            Shizuku.removeBinderDeadListener(dead)
        }
    }
    return state
}
