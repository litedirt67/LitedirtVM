package com.litedirt.vm.ui.shizuku

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.litedirt.vm.shizuku.ShizukuState
import com.litedirt.vm.shizuku.openDeveloperOptions
import com.litedirt.vm.shizuku.openShizukuOrInstall
import com.litedirt.vm.shizuku.rememberShizukuState

private data class GuideStep(val title: String, val detail: String)

private val steps = listOf(
    GuideStep(
        "Aktifkan Opsi pengembang",
        "Pengaturan > Tentang ponsel > ketuk \"Nomor build\" 7 kali.",
    ),
    GuideStep(
        "Aktifkan Wireless debugging",
        "Sambungkan ke Wi-Fi, lalu nyalakan \"Wireless debugging\" di Opsi pengembang.",
    ),
    GuideStep(
        "Buka Shizuku dan pilih Pairing",
        "Di aplikasi Shizuku, bagian \"Start via Wireless debugging\", ketuk \"Pairing\".",
    ),
    GuideStep(
        "Pasangkan dengan kode",
        "Di Wireless debugging ketuk \"Pair device with pairing code\", lalu masukkan kode lewat notifikasi Shizuku.",
    ),
    GuideStep(
        "Start Shizuku",
        "Kembali ke Shizuku dan ketuk \"Start\". Setelah status Berjalan, kembali ke sini dan beri izin Shizuku.",
    ),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShizukuGuideScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val state by rememberShizukuState()
    val done = rememberSaveable(
        saver = listSaver(
            save = { it.toList() },
            restore = { mutableStateListOf<Boolean>().apply { addAll(it) } },
        )
    ) { mutableStateListOf<Boolean>().apply { repeat(steps.size) { add(false) } } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Panduan Shizuku") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { StatusCard(state) }
            item { ShizukuRestartBanner(state = state, modifier = Modifier.fillMaxWidth()) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { context.openDeveloperOptions() }) {
                        Text("Buka Opsi pengembang")
                    }
                    Button(onClick = { context.openShizukuOrInstall() }) {
                        Text(if (state == ShizukuState.NOT_INSTALLED) "Pasang Shizuku" else "Buka Shizuku")
                    }
                }
            }
            itemsIndexed(steps) { index, step ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                        Checkbox(checked = done[index], onCheckedChange = { done[index] = it })
                        Column(Modifier.padding(start = 8.dp)) {
                            Text("${index + 1}. ${step.title}", style = MaterialTheme.typography.titleSmall)
                            Text(step.detail, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
            item {
                Text(
                    "Catatan: Wireless debugging hanya tersedia di Android 11 ke atas pada ponsel host.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}

@Composable
private fun StatusCard(state: ShizukuState) {
    val label = when (state) {
        ShizukuState.NOT_INSTALLED -> "Shizuku belum terpasang"
        ShizukuState.NOT_RUNNING -> "Shizuku terpasang, belum berjalan"
        ShizukuState.RUNNING -> "Shizuku berjalan"
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("Status", style = MaterialTheme.typography.labelMedium)
            Text(label, style = MaterialTheme.typography.titleMedium)
        }
    }
}
