package com.litedirt.vm.ui.shizuku

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.litedirt.vm.shizuku.ShizukuState

/**
 * Pengingat yang tampil selama Shizuku TIDAK berjalan.
 * Pasang di layar utama dan di layar panduan. Hilang otomatis saat RUNNING.
 */
@Composable
fun ShizukuRestartBanner(
    state: ShizukuState,
    modifier: Modifier = Modifier,
    onOpenGuide: (() -> Unit)? = null,
) {
    if (state == ShizukuState.RUNNING) return

    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer,
            contentColor = MaterialTheme.colorScheme.onErrorContainer,
        ),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                text = "Shizuku perlu di-start ulang setelah ponsel restart.",
                style = MaterialTheme.typography.titleSmall,
            )
            Text(
                text = "Fitur root/Shizuku dinonaktifkan sementara sampai Shizuku berjalan.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 4.dp),
            )
            if (onOpenGuide != null) {
                TextButton(onClick = onOpenGuide) { Text("Lihat panduan") }
            }
        }
    }
}
